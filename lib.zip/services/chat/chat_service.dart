import 'package:hive_ce/hive.dart';
import 'package:phro/infrastructures/llm_client.dart';
import 'package:phro/services/agent/agent.dart';
import 'package:phro/services/chat/chat.dart';
import 'package:phro/services/chat/message.dart';
import 'package:phro/services/tool/tool_service.dart';

class ChatService {
  static final ChatService instance = ChatService._();

  static const String _boxName = 'chats';

  final LLMClient _llmClient;
  final ToolService _toolService;
  late Box<Map<dynamic, dynamic>> _box;
  late Agent agent;

  // 私有构造函数，防止外部调用构造函数
  ChatService._()
    : _llmClient = LLMClient.instance, // ← 这里初始化
      _toolService = ToolService.instance,
      agent = Agent();

  ChatService.forTest({
    LLMClient? llmClient,
    ToolService? toolService,
    required Box<Map<dynamic, dynamic>> box,
    Agent? agent,
  }) : _llmClient = llmClient ?? LLMClient.instance,
       _toolService = toolService ?? ToolService.instance,
       _box = box, // 测试时必须传入
       agent = agent ?? Agent();

  // 存聊天记录就用Hive，别想着存文件了。性能差
  Future<void> initHiveBox() async {
    _box = await Hive.openBox<Map>(_boxName);
  }

  Future<List<Chat>> getAllChats() async {
    final chats = _box.values
        .map((data) => Chat.fromMap(Map<String, dynamic>.from(data)))
        .toList();
    chats.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return chats;
  }

  Future<Chat> getChatById(String id) async {
    final data = _box.get(id);
    if (data == null) {
      throw Exception("ChatId $id doesn't exist");
    }
    return Chat.fromMap(Map<String, dynamic>.from(data));
  }

  Future<void> updateChatTitle(String id, String newTitle) async {
    final data = _box.get(id);
    if (data == null) return;
    final chatMap = Map<String, dynamic>.from(data);
    chatMap['title'] = newTitle.trim(); // 只更新标题
    await _box.put(id, chatMap);
  }

  Future<void> deleteChat(String id) async {
    await _box.delete(id);
  }

  // 每次返回完整的消息列表
  Stream<List<Message>> sendMessage({
    required String chatId,
    required String content,
  }) async* {
    Chat chat = await getChatById(chatId);

    // 1. 添加用户消息
    final userMsg = Message(
      role: 'user',
      content: content,
      reasoningContent: null,
    );
    chat.addMessage(userMsg);
    try {
      while (true) {
        // 先搞一个空会话，前端展示空气泡
        Message assistantMessage = Message(role: 'assistant', content: '');
        chat.addMessage(assistantMessage);
        yield chat.messages.toList();
        // 存流结果用的
        String fullContent = '';
        String fullReasoningContent = '';
        final fullToolCalls = <int, Map<String, dynamic>>{};
        List<Map<String, dynamic>> fullToolCallsList = [];
        // 开始调用api，同步更新最后一条消息
        await for (final chunk in _llmClient.sendMessageStream(
          chat.messages.map((messaage) => messaage.toMap4Api()).toList(),
          agent.tools,
        )) {
          final type = chunk['type'] as String?;
          final content = chunk['content'];
          if (type == 'error') {
            assistantMessage.update(error: content as String);
            yield chat.messages.toList();
            return; // 错误时提前结束
          }
          switch (type) {
            case 'content':
              fullContent += content as String? ?? '';
              break;
            case 'reasoning_content':
              fullReasoningContent += content as String? ?? '';
              break;
            case 'tool_calls':
              _accumulateToolCalls(content, fullToolCalls);
              break;
          }
          // Map转列表
          fullToolCallsList = [
            for (var key in fullToolCalls.keys.toList()..sort())
              fullToolCalls[key]!,
          ];
          // 流一更新消息就要更新，前端也实时更新
          assistantMessage.update(
            content: fullContent,
            reasoningContent: fullReasoningContent,
            toolCalls: fullToolCallsList,
          );
          yield chat.messages.toList();
        } // 流结束

        if (fullToolCallsList.isEmpty) {
          // 普通对话，直接结束本次 while
          break;
        }

        yield* _executeToolCalls(fullToolCallsList, chat);
      } // 循环结束
    } finally {
      await _saveChat(chat);
    }
  }

  // 执行tool call并更新Chat
  Stream<List<Message>> _executeToolCalls(
    List<Map<String, dynamic>> fullToolCallsList,
    Chat chat,
  ) async* {
    for (final toolJson in fullToolCallsList) {
      final function = toolJson['function'];
      Message toolMessage = Message(
        role: 'tool',
        content: "正在执行工具 '$function[name']...",
        toolCallId: toolJson['id'],
      );
      chat.addMessage(toolMessage);
      yield chat.messages.toList();

      final String toolResult = await _toolService.execute(
        function['name'],
        function['arguments'],
      );
      toolMessage.update(content: toolResult);
      yield chat.messages.toList();
    }
  }

  void _accumulateToolCalls(
    List toolCallList,
    Map<int, Map<String, dynamic>> fullToolCalls,
  ) {
    for (final toolCallChunk in toolCallList) {
      final index = toolCallChunk['index'];
      // 第一次遇到这个 index 时初始化
      if (!fullToolCalls.containsKey(index)) {
        fullToolCalls[index] = {
          "id": toolCallChunk['id'],
          "type": toolCallChunk['type'] ?? "function",
          "function": {
            "name": toolCallChunk['function']['name'] ?? "",
            "arguments": "",
          },
        };
      } else {
        // 累加 arguments（最关键的部分）
        final prevArgs =
            fullToolCalls[index]!["function"]["arguments"] as String;
        final newArgs = toolCallChunk['function']['arguments'];
        if (newArgs != null && newArgs.isNotEmpty) {
          fullToolCalls[index]!["function"]["arguments"] = prevArgs + newArgs;
        }
      }
    }
  }

  // 创建新对话，添加系统消息，落库
  Future<String> createChat({String? title}) async {
    final chat = Chat(title: title);
    chat.addMessage(
      Message(
        role: 'system',
        content: agent.systemPrompt,
        reasoningContent: null,
      ),
    );
    await _saveChat(chat);
    return chat.id;
  }

  // 对话历史记录存数据库
  Future<void> _saveChat(Chat chat) async {
    await _box.put(chat.id, chat.toMap());
  }
}
